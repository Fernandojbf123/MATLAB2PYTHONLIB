# Descripción de la librería

# MATLAB2PYTHONLIB

Esta es una librería de Python con funciones útiles.

## Instalación

```bash
pip install mi_libreria