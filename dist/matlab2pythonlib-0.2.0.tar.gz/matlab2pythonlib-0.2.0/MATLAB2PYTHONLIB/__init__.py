# Hace que Python trate esta carpeta como un paquete
from .functions import datenum_to_date